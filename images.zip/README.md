# Forum_project
I have created a forum project like a actual forum ,I had keep a login and signup functionality in it. if someone want to contribute in forum without any login then he/she can't get access , they can see all the thing but can't contribute in it without login.  
