<div class="container-fluid bg-dark text-light">
 <p class=" text-center ">Copyright iDiscuss coding forum 2021| All rights reserved</p>
</div>