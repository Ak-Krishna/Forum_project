<?php
 $server="localhost";
 $username="root";
 $password="";
 $database="Iforum";
 $conn=mysqli_connect($server,$username,$password,$database);
?>